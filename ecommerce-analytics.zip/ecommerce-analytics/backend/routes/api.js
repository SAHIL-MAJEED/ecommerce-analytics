const express = require('express');
const router = express.Router();

// Test Route
router.get('/test', (req, res) => {
  res.json({ message: 'API is working!' });
});

// More routes will be added here later

module.exports = router;
const mongoose = require('mongoose');

// MongoDB Schema for Orders (Example)
const orderSchema = new mongoose.Schema({
  created_at: Date,
  total_price_set: {
    shop_money: {
      amount: Number
    }
  }
}, { collection: 'shopifyOrders' });

const Order = mongoose.model('Order', orderSchema);

router.get('/sales-over-time', async (req, res) => {
  try {
    const result = await Order.aggregate([
      {
        $group: {
          _id: { month: { $month: "$created_at" }, year: { $year: "$created_at" } },
          totalSales: { $sum: "$total_price_set.shop_money.amount" }
        }
      }
    ]);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
