import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';

const SalesOverTimeChart = () => {
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/sales-over-time')
      .then(response => setSalesData(response.data))
      .catch(error => console.error(error));
  }, []);

  const data = {
    labels: salesData.map(item => `${item._id.month}-${item._id.year}`),
    datasets: [
      {
        label: 'Total Sales',
        data: salesData.map(item => item.totalSales),
        borderColor: 'rgba(75, 192, 192, 1)',
        fill: false
      }
    ]
  };

  return <Line data={data} />;
};

export default SalesOverTimeChart;
