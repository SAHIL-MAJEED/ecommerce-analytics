import React from 'react';
import SalesOverTimeChart from './components/SalesOverTimeChart';

function App() {
  return (
    <div className="App">
      <h1>E-commerce Analytics</h1>
      <SalesOverTimeChart />
    </div>
  );
}

export default App;
